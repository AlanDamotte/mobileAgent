package jus.aor.mobilagent.kernel;

public interface _Server {

}
